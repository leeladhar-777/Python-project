# FuelSense Interactive Website (Browser Demo)

## Run
1. Extract this folder.
2. Double-click `index.html` to open it in Chrome, Edge, or Firefox.
3. Use **Add fuel record** to add fuel purchases; use the sidebar to add a vehicle, filter records, and export CSV.

## Included interactions
- Sample dashboard data and responsive UI
- Add vehicles and fuel records with validation
- Local browser storage so records remain after refresh in the same browser
- Vehicle filter, approximate mileage, cost/km, monthly and mileage charts
- CSV export and reset-demo action
- Full-tank versus partial-fill limitations explained in the interface

## Important
This standalone browser version stores data in your browser's localStorage. It does not connect to MySQL and is best for an interactive demo/prototype. For a database-backed version, use the separate `FuelSense_Website_Project.zip` Flask + MySQL project. Do not use localStorage for sensitive or multi-user production data.
