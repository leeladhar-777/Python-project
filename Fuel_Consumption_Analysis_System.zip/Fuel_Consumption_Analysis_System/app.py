# Small Flask API for vehicles and fuel records.
# Database details are read from environment variables.

import os
from datetime import date
from flask import Flask, jsonify, request
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)


def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "fuel_analysis")
    )


def error_response(message, status_code):
    return jsonify({"error": message}), status_code


@app.get("/")
def home():
    return jsonify({
        "message": "Fuel Consumption Analysis System API",
        "routes": ["/vehicles", "/fuel-records"]
    })


@app.get("/vehicles")
def list_vehicles():
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            "SELECT vehicle_id, vehicle_code, vehicle_type, fuel_type "
            "FROM vehicles ORDER BY vehicle_code"
        )
        rows = cursor.fetchall()
        return jsonify(rows)
    except Error:
        return error_response("Could not read vehicles. Check MySQL setup.", 500)
    finally:
        if "cursor" in locals():
            cursor.close()
        if "connection" in locals() and connection.is_connected():
            connection.close()


@app.post("/vehicles")
def add_vehicle():
    data = request.get_json(silent=True) or {}
    code = str(data.get("vehicle_code", "")).strip()
    vehicle_type = str(data.get("vehicle_type", "")).strip()
    fuel_type = str(data.get("fuel_type", "")).strip()

    if not code or not vehicle_type or not fuel_type:
        return error_response(
            "Please provide vehicle_code, vehicle_type and fuel_type.", 400
        )

    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO vehicles (vehicle_code, vehicle_type, fuel_type) "
            "VALUES (%s, %s, %s)",
            (code, vehicle_type, fuel_type)
        )
        connection.commit()
        return jsonify({"message": "Vehicle added.", "vehicle_id": cursor.lastrowid}), 201
    except Error as exc:
        if connection:
            connection.rollback()
        if getattr(exc, "errno", None) == 1062:
            return error_response("That vehicle code already exists.", 409)
        return error_response("Could not save vehicle. Check the input and database.", 500)
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


@app.get("/fuel-records")
def list_fuel_records():
    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT r.record_id, v.vehicle_code, r.fill_date, r.odometer_km,
                   r.litres, r.total_cost, r.full_tank_flag
            FROM fuel_records r
            JOIN vehicles v ON v.vehicle_id = r.vehicle_id
            ORDER BY v.vehicle_code, r.fill_date, r.record_id
        """)
        return jsonify(cursor.fetchall())
    except Error:
        return error_response("Could not read fuel records. Check MySQL setup.", 500)
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


@app.post("/fuel-records")
def add_fuel_record():
    data = request.get_json(silent=True) or {}
    required = ["vehicle_id", "fill_date", "odometer_km", "litres", "total_cost"]
    missing = [field for field in required if field not in data]
    if missing:
        return error_response("Missing fields: " + ", ".join(missing), 400)

    try:
        vehicle_id = int(data["vehicle_id"])
        odometer = float(data["odometer_km"])
        litres = float(data["litres"])
        cost = float(data["total_cost"])
        fill_date = date.fromisoformat(str(data["fill_date"]))
    except (TypeError, ValueError):
        return error_response("Check the date and numeric values.", 400)

    full_tank = data.get("full_tank_flag", True)
    if not isinstance(full_tank, bool):
        return error_response("full_tank_flag must be true or false.", 400)
    if vehicle_id <= 0 or odometer < 0 or litres <= 0 or cost < 0:
        return error_response(
            "Vehicle ID must be positive, odometer cannot be negative, "
            "litres must be above zero and cost cannot be negative.", 400
        )

    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(
            "SELECT record_id, fill_date, odometer_km FROM fuel_records "
            "WHERE vehicle_id = %s ORDER BY fill_date DESC, record_id DESC LIMIT 1",
            (vehicle_id,)
        )
        previous = cursor.fetchone()
        if previous:
            if fill_date < previous["fill_date"]:
                return error_response("The fill date must not be earlier than the latest record.", 400)
            if fill_date == previous["fill_date"] and odometer < float(previous["odometer_km"]):
                return error_response("Odometer reading cannot go backwards.", 400)
            if odometer <= float(previous["odometer_km"]):
                return error_response("Odometer reading must be greater than the previous reading.", 400)

        cursor.execute(
            "INSERT INTO fuel_records "
            "(vehicle_id, fill_date, odometer_km, litres, total_cost, full_tank_flag) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            (vehicle_id, fill_date, odometer, litres, cost, full_tank)
        )
        connection.commit()
        return jsonify({"message": "Fuel record added.", "record_id": cursor.lastrowid}), 201
    except Error:
        if connection:
            connection.rollback()
        return error_response("Could not save fuel record. Check the vehicle ID and database.", 500)
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


if __name__ == "__main__":
    # Debug is off by default. This is a student development project.
    app.run(host="127.0.0.1", port=5000, debug=False)
